"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface PulseDetectorProps {
  onPulseDetected: (data: { heartRate: number; dosha: string }) => void
  isLoading?: boolean
}

export function PulseDetector({ onPulseDetected, isLoading = false }: PulseDetectorProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDetecting, setIsDetecting] = useState(false)
  const [heartRate, setHeartRate] = useState<number | null>(null)
  const [message, setMessage] = useState("")
  const [cameraActive, setCameraActive] = useState(false)

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setCameraActive(true)
        setMessage("Camera active. Place your finger on the camera lens.")
      }
    } catch (err) {
      setMessage("Unable to access camera. Please check permissions.")
    }
  }

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
      tracks.forEach((track) => track.stop())
      setCameraActive(false)
    }
  }

  const detectPulse = async () => {
    if (!videoRef.current || !canvasRef.current) return

    setIsDetecting(true)
    setMessage("Analyzing pulse... Please keep your finger steady.")

    // Simulate pulse detection with Fourier analysis
    // In production, this would use actual video frame analysis
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Capture frames and analyze red channel intensity
    const redValues: number[] = []
    let frameCount = 0
    const targetFrames = 150 // ~5 seconds at 30fps

    const analyzeFrame = () => {
      if (frameCount < targetFrames && videoRef.current) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const data = imageData.data

        // Extract red channel values
        let redSum = 0
        for (let i = 0; i < data.length; i += 4) {
          redSum += data[i] // Red channel
        }
        redValues.push(redSum / (canvas.width * canvas.height))
        frameCount++

        requestAnimationFrame(analyzeFrame)
      } else {
        // Calculate heart rate from red channel oscillations
        const detectedHeartRate = calculateHeartRate(redValues)
        setHeartRate(detectedHeartRate)
        setMessage(`Heart rate detected: ${detectedHeartRate} BPM`)
        setIsDetecting(false)

        // Determine dosha based on heart rate and pattern
        const dosha = determineDosha(detectedHeartRate)
        onPulseDetected({ heartRate: detectedHeartRate, dosha })
      }
    }

    analyzeFrame()
  }

  const calculateHeartRate = (redValues: number[]): number => {
    // Simple FFT-like analysis to find dominant frequency
    // In production, use actual FFT library
    if (redValues.length < 2) return 60

    // Calculate differences to find oscillations
    const diffs = []
    for (let i = 1; i < redValues.length; i++) {
      diffs.push(Math.abs(redValues[i] - redValues[i - 1]))
    }

    // Find peaks (heartbeats)
    let peaks = 0
    const threshold = Math.max(...diffs) * 0.5
    for (let i = 1; i < diffs.length - 1; i++) {
      if (diffs[i] > threshold && diffs[i] > diffs[i - 1] && diffs[i] > diffs[i + 1]) {
        peaks++
      }
    }

    // Convert peaks to BPM (assuming 5 seconds of data)
    const heartRate = Math.round((peaks / 5) * 60)
    return Math.max(40, Math.min(200, heartRate)) // Clamp to reasonable range
  }

  const determineDosha = (heartRate: number): string => {
    // Simplified dosha determination based on heart rate
    if (heartRate < 60) return "Kapha"
    if (heartRate < 80) return "Pitta"
    return "Vata"
  }

  return (
    <Card className="p-6 bg-card border-border">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-2">Pulse Detection via Camera</h3>
          <p className="text-sm text-muted-foreground">
            Place your finger on the camera lens to detect your pulse using light intensity analysis.
          </p>
        </div>

        {cameraActive ? (
          <div className="space-y-4">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full rounded-lg bg-black"
              style={{ maxHeight: "300px" }}
            />
            <canvas ref={canvasRef} className="hidden" width={640} height={480} />

            <div className="flex gap-2">
              <Button
                onClick={detectPulse}
                disabled={isDetecting || isLoading}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {isDetecting ? "Analyzing..." : "Detect Pulse"}
              </Button>
              <Button
                onClick={stopCamera}
                variant="outline"
                className="flex-1 border-border hover:bg-secondary/50 bg-transparent"
              >
                Stop Camera
              </Button>
            </div>
          </div>
        ) : (
          <Button
            onClick={startCamera}
            disabled={isLoading}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Start Camera
          </Button>
        )}

        {message && (
          <div
            className={`p-3 rounded-lg text-sm ${heartRate ? "bg-primary/10 text-primary" : "bg-secondary/10 text-foreground"}`}
          >
            {message}
          </div>
        )}

        {heartRate && (
          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <p className="text-sm text-muted-foreground mb-1">Detected Heart Rate</p>
            <p className="text-3xl font-bold text-primary">{heartRate} BPM</p>
          </div>
        )}
      </div>
    </Card>
  )
}
