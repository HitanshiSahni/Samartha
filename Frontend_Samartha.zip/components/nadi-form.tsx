"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"

interface NadiFormData {
  bodyFrame: string
  hairType: string
  hairColor: string
  skin: string
  complexion: string
  bodyWeight: string
  nails: string
  teeth: string
  workPace: string
  mentalActivity: string
  memory: string
  sleepPattern: string
  weatherPreference: string
  adverseReaction: string
  mood: string
  eatingHabit: string
  hunger: string
  bodyTemperature: string
  joints: string
  nature: string
  socialRelations: string
}

interface NadiFormProps {
  onSubmit: (data: NadiFormData) => void
  isLoading?: boolean
}

export function NadiForm({ onSubmit, isLoading = false }: NadiFormProps) {
  const [formData, setFormData] = useState<NadiFormData>({
    bodyFrame: "",
    hairType: "",
    hairColor: "",
    skin: "",
    complexion: "",
    bodyWeight: "",
    nails: "",
    teeth: "",
    workPace: "",
    mentalActivity: "",
    memory: "",
    sleepPattern: "",
    weatherPreference: "",
    adverseReaction: "",
    mood: "",
    eatingHabit: "",
    hunger: "",
    bodyTemperature: "",
    joints: "",
    nature: "",
    socialRelations: "",
  })

  const handleChange = (field: keyof NadiFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const formSections = [
    {
      title: "Physical Characteristics",
      fields: [
        { key: "bodyFrame", label: "Body Frame", options: ["Thin", "Lean", "Medium", "Well Built"] },
        { key: "hairType", label: "Hair Type", options: ["Normal", "Dry", "Greasy"] },
        { key: "hairColor", label: "Hair Color", options: ["Black", "Brown", "Grey"] },
        { key: "skin", label: "Skin Type", options: ["Soft, Sweating", "Moist, Greasy", "Dry, Rough"] },
        { key: "complexion", label: "Complexion", options: ["Glowing", "Pinkish", "Dark"] },
        { key: "bodyWeight", label: "Body Weight", options: ["Underweight", "Normal", "Overweight"] },
        { key: "nails", label: "Nails Color", options: ["Reddish", "Pinkish", "Blackish"] },
        { key: "teeth", label: "Teeth", options: ["Large, White", "Medium, Yellowish", "Irregular, Blackish"] },
      ],
    },
    {
      title: "Behavioral & Mental",
      fields: [
        { key: "workPace", label: "Pace of Work", options: ["Low", "Medium", "Fast"] },
        { key: "mentalActivity", label: "Mental Activity", options: ["Aggressive", "Restless", "Stable"] },
        { key: "memory", label: "Memory", options: ["Short Term", "Long Term", "Good Memory"] },
        { key: "sleepPattern", label: "Sleep Pattern", options: ["Less", "Moderate", "Sleepy"] },
        {
          key: "weatherPreference",
          label: "Weather Preference",
          options: ["Dislike Heat", "Dislike Cold", "Dislike Moist"],
        },
        { key: "adverseReaction", label: "Reaction to Stress", options: ["Anger", "Calm", "Anxiety"] },
        { key: "mood", label: "Mood Changes", options: ["Changes Quickly", "Changes Slowly", "Constant"] },
      ],
    },
    {
      title: "Lifestyle & Health",
      fields: [
        {
          key: "eatingHabit",
          label: "Eating Habit",
          options: ["Improper Chewing", "Proper Chewing", "Irregular Chewing"],
        },
        { key: "hunger", label: "Hunger Pattern", options: ["Irregular", "Sudden & Sharp", "Skips Meals"] },
        {
          key: "bodyTemperature",
          label: "Body Temperature",
          options: ["Less Than Normal", "Normal", "More Than Normal"],
        },
        { key: "joints", label: "Joints", options: ["Weak", "Healthy", "Heavy"] },
        { key: "nature", label: "Nature", options: ["Forgiving, Grateful", "Egoist, Fearless", "Jealousy, Fearful"] },
        { key: "socialRelations", label: "Social Relations", options: ["Introvert", "Extrovert", "Ambivert"] },
      ],
    },
  ]

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {formSections.map((section) => (
        <div key={section.title}>
          <h3 className="text-lg font-semibold text-foreground mb-4 pb-2 border-b border-border">{section.title}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {section.fields.map((field) => (
              <div key={field.key}>
                <label className="block text-sm font-medium text-foreground mb-2">{field.label}</label>
                <select
                  value={formData[field.key as keyof NadiFormData]}
                  onChange={(e) => handleChange(field.key as keyof NadiFormData, e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">Select an option</option>
                  {field.options.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>
      ))}

      <Button
        type="submit"
        disabled={isLoading}
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
      >
        {isLoading ? "Processing..." : "Calculate Dosha"}
      </Button>
    </form>
  )
}
