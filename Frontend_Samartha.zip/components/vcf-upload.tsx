"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface VCFUploadProps {
  onFileSelect: (file: File) => void
  isLoading?: boolean
}

export function VCFUpload({ onFileSelect, isLoading = false }: VCFUploadProps) {
  const [fileName, setFileName] = useState<string>("")
  const [isDragActive, setIsDragActive] = useState(false)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true)
    } else if (e.type === "dragleave") {
      setIsDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragActive(false)

    const files = e.dataTransfer.files
    if (files && files[0]) {
      const file = files[0]
      if (file.name.endsWith(".vcf") || file.type === "text/plain") {
        setFileName(file.name)
        onFileSelect(file)
      }
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setFileName(file.name)
      onFileSelect(file)
    }
  }

  return (
    <Card
      className={`p-8 border-2 border-dashed transition-colors ${
        isDragActive ? "border-primary bg-primary/5" : "border-border bg-card"
      }`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      <div className="text-center">
        <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">🧬</span>
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Upload VCF File</h3>
        <p className="text-muted-foreground mb-4">Drag and drop your genomic VCF file here, or click to browse</p>

        {fileName && <p className="text-sm text-primary font-medium mb-4">Selected: {fileName}</p>}

        <label>
          <input type="file" accept=".vcf,.txt" onChange={handleFileInput} className="hidden" disabled={isLoading} />
          <Button
            type="button"
            variant="outline"
            className="border-border hover:bg-secondary/50 bg-transparent"
            onClick={(e) => {
              e.preventDefault()
              const input = e.currentTarget.previousElementSibling as HTMLInputElement
              input?.click()
            }}
            disabled={isLoading}
          >
            {isLoading ? "Processing..." : "Choose File"}
          </Button>
        </label>
      </div>
    </Card>
  )
}
