"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface RiskDistributionChartProps {
  userRisk: number
  populationMean: number
  populationStd: number
  disease: string
}

export function RiskDistributionChart({
  userRisk,
  populationMean,
  populationStd,
  disease,
}: RiskDistributionChartProps) {
  // Generate bell curve data
  const data = []
  for (let i = populationMean - 3 * populationStd; i <= populationMean + 3 * populationStd; i += populationStd * 0.5) {
    const x = i
    // Normal distribution formula
    const exponent = -Math.pow(x - populationMean, 2) / (2 * Math.pow(populationStd, 2))
    const y = (1 / (populationStd * Math.sqrt(2 * Math.PI))) * Math.exp(exponent)
    data.push({ risk: Math.round(x), frequency: y * 100 })
  }

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
          <XAxis dataKey="risk" stroke="var(--color-muted-foreground)" />
          <YAxis stroke="var(--color-muted-foreground)" />
          <Tooltip
            contentStyle={{
              backgroundColor: "var(--color-card)",
              border: `1px solid var(--color-border)`,
              borderRadius: "8px",
            }}
            cursor={{ fill: "var(--color-primary)" }}
          />
          <Bar dataKey="frequency" fill="var(--color-primary)" opacity={0.7} />
        </BarChart>
      </ResponsiveContainer>
      <div className="mt-4 flex items-center justify-center gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-muted-foreground">Population Distribution</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-accent" />
          <span className="text-muted-foreground">Your Risk: {userRisk}%</span>
        </div>
      </div>
    </div>
  )
}
