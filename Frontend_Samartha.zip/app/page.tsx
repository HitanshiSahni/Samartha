"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Footer } from "@/components/footer"

export default function LandingPage() {
  const [isLoginOpen, setIsLoginOpen] = useState(false)
  const [isSignupOpen, setIsSignupOpen] = useState(false)

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
        {/* Hero Section */}
        <section className="max-w-6xl mx-auto px-6 py-20 text-center">
          <div className="space-y-6 mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight text-balance">
              Your Personalized Health Intelligence System
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed text-pretty">
              Transform your genomic data into actionable health insights. Detect risks before symptoms appear with
              AI-powered preventive healthcare recommendations.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button
              size="lg"
              onClick={() => setIsSignupOpen(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 transition-all hover:shadow-lg"
            >
              Get Started
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-border hover:bg-secondary/50 px-8 bg-transparent transition-all hover:shadow-lg"
            >
              Learn More
            </Button>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-16">
            <Card className="p-6 bg-card border-border hover:shadow-lg transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl">🧬</span>
              </div>
              <h3 className="font-semibold text-lg mb-2 text-foreground">Genomic Analysis</h3>
              <p className="text-muted-foreground">
                Upload your VCF file and get comprehensive disease risk assessment using advanced GWAS analysis.
              </p>
            </Card>

            <Card className="p-6 bg-card border-border hover:shadow-lg transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl">❤️</span>
              </div>
              <h3 className="font-semibold text-lg mb-2 text-foreground">Nadi Pariksha</h3>
              <p className="text-muted-foreground">
                Detect your pulse pattern using camera technology combined with Ayurvedic assessment.
              </p>
            </Card>

            <Card className="p-6 bg-card border-border hover:shadow-lg transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl">🎯</span>
              </div>
              <h3 className="font-semibold text-lg mb-2 text-foreground">Smart Recommendations</h3>
              <p className="text-muted-foreground">
                Get personalized diet and yoga plans from Ayurvedic or Allopathic medicine based on your profile.
              </p>
            </Card>
          </div>
        </section>

        {/* Login Modal */}
        {isLoginOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <Card className="w-full max-w-md bg-card border-border shadow-xl">
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-foreground">Log in</h2>
                  <button
                    onClick={() => setIsLoginOpen(false)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    ✕
                  </button>
                </div>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Password</label>
                    <input
                      type="password"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      placeholder="••••••••"
                    />
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all">
                    Log in
                  </Button>
                </form>
                <p className="text-center text-muted-foreground text-sm mt-4">
                  Don't have an account?{" "}
                  <button
                    onClick={() => {
                      setIsLoginOpen(false)
                      setIsSignupOpen(true)
                    }}
                    className="text-primary hover:underline font-medium transition-colors"
                  >
                    Sign up
                  </button>
                </p>
              </div>
            </Card>
          </div>
        )}

        {/* Signup Modal */}
        {isSignupOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <Card className="w-full max-w-md bg-card border-border shadow-xl">
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-foreground">Create account</h2>
                  <button
                    onClick={() => setIsSignupOpen(false)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    ✕
                  </button>
                </div>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Full Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Password</label>
                    <input
                      type="password"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      placeholder="••••••••"
                    />
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all">
                    Create account
                  </Button>
                </form>
                <p className="text-center text-muted-foreground text-sm mt-4">
                  Already have an account?{" "}
                  <button
                    onClick={() => {
                      setIsSignupOpen(false)
                      setIsLoginOpen(true)
                    }}
                    className="text-primary hover:underline font-medium transition-colors"
                  >
                    Log in
                  </button>
                </p>
              </div>
            </Card>
          </div>
        )}
      </div>
      <Footer />
    </>
  )
}
