"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface Exercise {
  id: string
  name: string
  duration: string
  intensity: string
  frequency: string
  benefits: string[]
  instructions: string[]
  reason: string
  medicine: "Ayurvedic" | "Allopathic"
}

export default function ExerciseRecommendationsPage() {
  const [selectedMedicine, setSelectedMedicine] = useState<"Ayurvedic" | "Allopathic">("Ayurvedic")
  const [expandedExercise, setExpandedExercise] = useState<string | null>(null)

  const exercises: Exercise[] = [
    {
      id: "1",
      name: "Yoga - Vata Balancing Sequence",
      duration: "30-45 minutes",
      intensity: "Moderate",
      frequency: "5-6 times per week",
      benefits: ["Improves circulation", "Reduces anxiety", "Strengthens joints", "Enhances flexibility"],
      instructions: [
        "Start with grounding poses like Mountain Pose (Tadasana)",
        "Practice slow, flowing movements with deep breathing",
        "Include forward bends and gentle twists",
        "End with 10 minutes of meditation",
      ],
      reason:
        "Vata dosha benefits from grounding, warming exercises. Yoga helps balance the air element and promotes stability.",
      medicine: "Ayurvedic",
    },
    {
      id: "2",
      name: "Walking - Brisk Morning Walk",
      duration: "30-40 minutes",
      intensity: "Moderate",
      frequency: "Daily",
      benefits: ["Improves cardiovascular health", "Reduces diabetes risk", "Boosts metabolism", "Enhances mood"],
      instructions: [
        "Walk at a pace where you can talk but not sing",
        "Maintain upright posture",
        "Swing arms naturally",
        "Walk on flat, even surfaces initially",
      ],
      reason:
        "Regular aerobic exercise reduces Type 2 Diabetes risk by 50%. Walking is accessible and effective for cardiovascular health.",
      medicine: "Allopathic",
    },
    {
      id: "3",
      name: "Pranayama - Alternate Nostril Breathing",
      duration: "10-15 minutes",
      intensity: "Low",
      frequency: "Daily, preferably morning",
      benefits: ["Balances nervous system", "Reduces stress", "Improves lung capacity", "Enhances mental clarity"],
      instructions: [
        "Sit in a comfortable cross-legged position",
        "Close right nostril, inhale through left for 4 counts",
        "Close left nostril, exhale through right for 4 counts",
        "Repeat 10-15 rounds",
      ],
      reason:
        "Pranayama regulates the flow of prana (life force) and helps balance all three doshas. Particularly beneficial for Vata imbalance.",
      medicine: "Ayurvedic",
    },
    {
      id: "4",
      name: "Resistance Training",
      duration: "45-60 minutes",
      intensity: "High",
      frequency: "3-4 times per week",
      benefits: ["Builds muscle mass", "Improves insulin sensitivity", "Strengthens bones", "Increases metabolism"],
      instructions: [
        "Warm up for 5-10 minutes",
        "Perform compound exercises (squats, deadlifts, bench press)",
        "Use moderate weights with controlled movements",
        "Rest 48 hours between sessions for same muscle groups",
      ],
      reason:
        "Resistance training improves insulin sensitivity and helps prevent Type 2 Diabetes. Builds lean muscle mass which increases metabolic rate.",
      medicine: "Allopathic",
    },
    {
      id: "5",
      name: "Surya Namaskar - Sun Salutation",
      duration: "15-20 minutes",
      intensity: "Moderate",
      frequency: "Daily, preferably at sunrise",
      benefits: ["Energizes body", "Improves flexibility", "Strengthens muscles", "Regulates digestion"],
      instructions: [
        "Perform 12 rounds of Sun Salutation",
        "Synchronize movement with breath",
        "Maintain steady pace throughout",
        "Practice on empty stomach for best results",
      ],
      reason:
        "Surya Namaskar is a complete body workout that balances all doshas. The rhythmic flow with breathing enhances cardiovascular and respiratory health.",
      medicine: "Ayurvedic",
    },
    {
      id: "6",
      name: "Swimming",
      duration: "30-45 minutes",
      intensity: "Moderate to High",
      frequency: "3-4 times per week",
      benefits: ["Full-body workout", "Low impact on joints", "Improves cardiovascular health", "Reduces stress"],
      instructions: [
        "Warm up with easy swimming for 5 minutes",
        "Alternate between different strokes",
        "Maintain steady breathing pattern",
        "Cool down with gentle swimming",
      ],
      reason:
        "Swimming provides excellent cardiovascular benefits with minimal joint stress. Ideal for heart disease prevention and overall fitness.",
      medicine: "Allopathic",
    },
  ]

  const filteredExercises = exercises.filter((ex) => ex.medicine === selectedMedicine)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Exercise Recommendations</h1>
          <p className="text-muted-foreground">Personalized workout plans based on your health profile and dosha</p>
        </div>

        {/* Medicine Selection */}
        <div className="flex gap-4 mb-8">
          <Button
            onClick={() => setSelectedMedicine("Ayurvedic")}
            className={`flex-1 ${
              selectedMedicine === "Ayurvedic"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary/50 text-foreground hover:bg-secondary"
            }`}
          >
            Ayurvedic Approach
          </Button>
          <Button
            onClick={() => setSelectedMedicine("Allopathic")}
            className={`flex-1 ${
              selectedMedicine === "Allopathic"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary/50 text-foreground hover:bg-secondary"
            }`}
          >
            Allopathic Approach
          </Button>
        </div>

        {/* Info Card */}
        <Card className="p-6 bg-primary/5 border border-primary/20 mb-8">
          <p className="text-sm text-muted-foreground mb-2">Recommended Approach</p>
          <p className="text-foreground">
            {selectedMedicine === "Ayurvedic"
              ? "Ayurvedic exercises focus on balancing your dosha and promoting harmony between body, mind, and spirit through gentle, mindful movement."
              : "Allopathic exercises are evidence-based, scientifically proven methods to improve cardiovascular health, manage weight, and prevent chronic diseases."}
          </p>
        </Card>

        {/* Exercises List */}
        <div className="space-y-4">
          {filteredExercises.map((exercise) => (
            <Card key={exercise.id} className="bg-card border-border overflow-hidden hover:shadow-lg transition-shadow">
              <button
                onClick={() => setExpandedExercise(expandedExercise === exercise.id ? null : exercise.id)}
                className="w-full p-6 text-left hover:bg-secondary/5 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-foreground mb-2">{exercise.name}</h3>
                    <div className="flex flex-wrap gap-3 text-sm">
                      <span className="text-muted-foreground">
                        <span className="font-medium text-foreground">Duration:</span> {exercise.duration}
                      </span>
                      <span className="text-muted-foreground">
                        <span className="font-medium text-foreground">Intensity:</span> {exercise.intensity}
                      </span>
                      <span className="text-muted-foreground">
                        <span className="font-medium text-foreground">Frequency:</span> {exercise.frequency}
                      </span>
                    </div>
                  </div>
                  <div className="text-2xl ml-4">{expandedExercise === exercise.id ? "−" : "+"}</div>
                </div>
              </button>

              {expandedExercise === exercise.id && (
                <div className="px-6 pb-6 border-t border-border pt-6 space-y-6">
                  {/* Benefits */}
                  <div>
                    <h4 className="font-semibold text-foreground mb-3">Benefits</h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {exercise.benefits.map((benefit, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <span className="text-primary mt-1">✓</span>
                          <span className="text-muted-foreground">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Instructions */}
                  <div>
                    <h4 className="font-semibold text-foreground mb-3">How to Perform</h4>
                    <ol className="space-y-2">
                      {exercise.instructions.map((instruction, idx) => (
                        <li key={idx} className="flex gap-3">
                          <span className="font-medium text-primary flex-shrink-0">{idx + 1}.</span>
                          <span className="text-muted-foreground">{instruction}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {/* Reason */}
                  <div className="p-4 bg-accent/5 border border-accent/20 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">Why This Exercise</p>
                    <p className="text-foreground">{exercise.reason}</p>
                  </div>

                  {/* Action Button */}
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    Add to My Routine
                  </Button>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Weekly Schedule Suggestion */}
        <Card className="p-8 bg-card border-border mt-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Suggested Weekly Schedule</h2>
          <div className="grid md:grid-cols-7 gap-2">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, idx) => (
              <div key={day} className="p-4 bg-secondary/10 border border-border rounded-lg text-center">
                <p className="font-semibold text-foreground mb-2">{day}</p>
                <p className="text-sm text-muted-foreground">{idx % 2 === 0 ? "Main Exercise" : "Light Activity"}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Tips Card */}
        <Card className="p-8 bg-primary/5 border border-primary/20 mt-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Important Tips</h2>
          <ul className="space-y-3">
            <li className="flex gap-3">
              <span className="text-primary font-bold">•</span>
              <span className="text-foreground">Start slowly and gradually increase intensity to avoid injury</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">•</span>
              <span className="text-foreground">Stay hydrated and maintain proper nutrition alongside exercise</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">•</span>
              <span className="text-foreground">
                Consistency is more important than intensity - aim for regular practice
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">•</span>
              <span className="text-foreground">Listen to your body and rest when needed to prevent overtraining</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
