"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface FoodItem {
  name: string
  category: string
  benefits: string[]
  frequency: string
  quantity: string
}

interface DietPlan {
  id: string
  meal: string
  time: string
  foods: FoodItem[]
  reason: string
}

export default function DietRecommendationsPage() {
  const [selectedMedicine, setSelectedMedicine] = useState<"Ayurvedic" | "Allopathic">("Ayurvedic")
  const [expandedMeal, setExpandedMeal] = useState<string | null>(null)

  const ayurvedicDiet: DietPlan[] = [
    {
      id: "1",
      meal: "Breakfast",
      time: "6:00 AM - 8:00 AM",
      foods: [
        {
          name: "Warm Ghee-Cooked Oatmeal",
          category: "Grains",
          benefits: ["Grounding", "Nourishing", "Digestive"],
          frequency: "Daily",
          quantity: "1 cup cooked",
        },
        {
          name: "Sesame Seeds",
          category: "Seeds",
          benefits: ["Warming", "Grounding", "Calcium-rich"],
          frequency: "Daily",
          quantity: "1 tablespoon",
        },
        {
          name: "Warm Milk with Turmeric",
          category: "Beverages",
          benefits: ["Anti-inflammatory", "Grounding", "Immune-boosting"],
          frequency: "Daily",
          quantity: "1 cup",
        },
      ],
      reason:
        "Warm, grounding foods balance Vata dosha. Ghee aids digestion and sesame provides warmth. Turmeric milk supports immunity and reduces inflammation.",
    },
    {
      id: "2",
      meal: "Lunch",
      time: "12:00 PM - 1:00 PM",
      foods: [
        {
          name: "Basmati Rice",
          category: "Grains",
          benefits: ["Easy to digest", "Grounding", "Nourishing"],
          frequency: "Daily",
          quantity: "1 cup cooked",
        },
        {
          name: "Mung Dal (Lentils)",
          category: "Legumes",
          benefits: ["Protein-rich", "Balancing", "Digestive"],
          frequency: "5-6 times/week",
          quantity: "1 cup cooked",
        },
        {
          name: "Steamed Vegetables (Carrots, Beets, Asparagus)",
          category: "Vegetables",
          benefits: ["Nutrient-dense", "Grounding", "Warming"],
          frequency: "Daily",
          quantity: "2 cups",
        },
        {
          name: "Ghee",
          category: "Fats",
          benefits: ["Digestive", "Nourishing", "Balancing"],
          frequency: "Daily",
          quantity: "1 teaspoon",
        },
      ],
      reason:
        "This meal provides balanced nutrition with easily digestible proteins and warming spices. Mung dal is considered the most balancing legume in Ayurveda.",
    },
    {
      id: "3",
      meal: "Dinner",
      time: "6:00 PM - 7:00 PM",
      foods: [
        {
          name: "Quinoa or Wheat",
          category: "Grains",
          benefits: ["Complete protein", "Grounding", "Nourishing"],
          frequency: "Daily",
          quantity: "1 cup cooked",
        },
        {
          name: "Roasted Root Vegetables",
          category: "Vegetables",
          benefits: ["Grounding", "Warming", "Stabilizing"],
          frequency: "Daily",
          quantity: "2 cups",
        },
        {
          name: "Bone Broth",
          category: "Broths",
          benefits: ["Nourishing", "Healing", "Grounding"],
          frequency: "3-4 times/week",
          quantity: "1 cup",
        },
      ],
      reason:
        "Light yet nourishing dinner that supports digestion before sleep. Root vegetables are grounding and warming, perfect for Vata balance.",
    },
  ]

  const allopathicDiet: DietPlan[] = [
    {
      id: "1",
      meal: "Breakfast",
      time: "7:00 AM - 8:00 AM",
      foods: [
        {
          name: "Oatmeal with Berries",
          category: "Grains & Fruits",
          benefits: ["High fiber", "Antioxidants", "Blood sugar control"],
          frequency: "Daily",
          quantity: "1 cup cooked + 1 cup berries",
        },
        {
          name: "Almonds",
          category: "Nuts",
          benefits: ["Healthy fats", "Protein", "Heart-healthy"],
          frequency: "Daily",
          quantity: "1 ounce (23 almonds)",
        },
        {
          name: "Green Tea",
          category: "Beverages",
          benefits: ["Antioxidants", "Metabolism boost", "Heart health"],
          frequency: "Daily",
          quantity: "1 cup",
        },
      ],
      reason:
        "High-fiber breakfast reduces diabetes risk by 30%. Berries provide antioxidants and green tea supports cardiovascular health.",
    },
    {
      id: "2",
      meal: "Lunch",
      time: "12:00 PM - 1:00 PM",
      foods: [
        {
          name: "Grilled Salmon",
          category: "Protein",
          benefits: ["Omega-3 fatty acids", "Heart-healthy", "Anti-inflammatory"],
          frequency: "3-4 times/week",
          quantity: "150g",
        },
        {
          name: "Brown Rice or Quinoa",
          category: "Grains",
          benefits: ["Complex carbs", "Fiber", "Sustained energy"],
          frequency: "Daily",
          quantity: "1 cup cooked",
        },
        {
          name: "Mixed Green Salad",
          category: "Vegetables",
          benefits: ["Vitamins", "Minerals", "Low glycemic"],
          frequency: "Daily",
          quantity: "2 cups",
        },
        {
          name: "Olive Oil Dressing",
          category: "Fats",
          benefits: ["Monounsaturated fats", "Heart-healthy"],
          frequency: "Daily",
          quantity: "1 tablespoon",
        },
      ],
      reason:
        "Omega-3 rich salmon reduces cardiovascular disease risk. Complex carbs maintain stable blood sugar. Salad provides essential micronutrients.",
    },
    {
      id: "3",
      meal: "Dinner",
      time: "6:00 PM - 7:00 PM",
      foods: [
        {
          name: "Lean Chicken Breast",
          category: "Protein",
          benefits: ["High protein", "Low fat", "Muscle building"],
          frequency: "4-5 times/week",
          quantity: "150g",
        },
        {
          name: "Sweet Potato",
          category: "Vegetables",
          benefits: ["Complex carbs", "Beta-carotene", "Fiber"],
          frequency: "3-4 times/week",
          quantity: "1 medium",
        },
        {
          name: "Steamed Broccoli",
          category: "Vegetables",
          benefits: ["Sulforaphane", "Antioxidants", "Cancer-fighting"],
          frequency: "Daily",
          quantity: "2 cups",
        },
      ],
      reason:
        "Lean protein supports muscle maintenance and metabolism. Sweet potatoes provide sustained energy. Broccoli contains compounds that reduce disease risk.",
    },
  ]

  const selectedDiet = selectedMedicine === "Ayurvedic" ? ayurvedicDiet : allopathicDiet

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Diet Recommendations</h1>
          <p className="text-muted-foreground">Personalized nutrition plans based on your health profile and dosha</p>
        </div>

        {/* Medicine Selection */}
        <div className="flex gap-4 mb-8">
          <Button
            onClick={() => setSelectedMedicine("Ayurvedic")}
            className={`flex-1 ${
              selectedMedicine === "Ayurvedic"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary/50 text-foreground hover:bg-secondary"
            }`}
          >
            Ayurvedic Approach
          </Button>
          <Button
            onClick={() => setSelectedMedicine("Allopathic")}
            className={`flex-1 ${
              selectedMedicine === "Allopathic"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary/50 text-foreground hover:bg-secondary"
            }`}
          >
            Allopathic Approach
          </Button>
        </div>

        {/* Info Card */}
        <Card className="p-6 bg-primary/5 border border-primary/20 mb-8">
          <p className="text-sm text-muted-foreground mb-2">Recommended Approach</p>
          <p className="text-foreground">
            {selectedMedicine === "Ayurvedic"
              ? "Ayurvedic nutrition focuses on balancing your dosha through warm, easily digestible foods that support your unique constitution and promote digestive fire (agni)."
              : "Allopathic nutrition is based on scientific evidence showing specific foods and nutrients that prevent chronic diseases like diabetes, heart disease, and stroke."}
          </p>
        </Card>

        {/* Daily Meal Plan */}
        <div className="space-y-4 mb-8">
          {selectedDiet.map((meal) => (
            <Card key={meal.id} className="bg-card border-border overflow-hidden hover:shadow-lg transition-shadow">
              <button
                onClick={() => setExpandedMeal(expandedMeal === meal.id ? null : meal.id)}
                className="w-full p-6 text-left hover:bg-secondary/5 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-foreground mb-1">{meal.meal}</h3>
                    <p className="text-sm text-muted-foreground">{meal.time}</p>
                  </div>
                  <div className="text-2xl ml-4">{expandedMeal === meal.id ? "−" : "+"}</div>
                </div>
              </button>

              {expandedMeal === meal.id && (
                <div className="px-6 pb-6 border-t border-border pt-6 space-y-6">
                  {/* Foods List */}
                  <div>
                    <h4 className="font-semibold text-foreground mb-4">Recommended Foods</h4>
                    <div className="space-y-4">
                      {meal.foods.map((food, idx) => (
                        <div key={idx} className="p-4 bg-card border border-border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <h5 className="font-medium text-foreground">{food.name}</h5>
                            <span className="text-xs font-semibold px-2 py-1 rounded bg-primary/10 text-primary">
                              {food.category}
                            </span>
                          </div>
                          <div className="grid md:grid-cols-2 gap-3 text-sm">
                            <div>
                              <p className="text-muted-foreground mb-1">
                                <span className="font-medium text-foreground">Quantity:</span> {food.quantity}
                              </p>
                              <p className="text-muted-foreground">
                                <span className="font-medium text-foreground">Frequency:</span> {food.frequency}
                              </p>
                            </div>
                            <div>
                              <p className="text-muted-foreground mb-1 font-medium">Benefits:</p>
                              <div className="flex flex-wrap gap-1">
                                {food.benefits.map((benefit, bidx) => (
                                  <span key={bidx} className="text-xs bg-accent/10 text-accent px-2 py-1 rounded">
                                    {benefit}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Reason */}
                  <div className="p-4 bg-accent/5 border border-accent/20 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">Why These Foods</p>
                    <p className="text-foreground">{meal.reason}</p>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Snacks & Hydration */}
        <Card className="p-8 bg-card border-border mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Snacks & Hydration</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-foreground mb-3">Recommended Snacks</h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Fresh fruits (apples, pears, dates)</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Nuts and seeds (almonds, walnuts)</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Herbal teas with honey</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Vegetable sticks with hummus</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-3">Hydration Guidelines</h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Drink 8-10 glasses of water daily</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Warm water aids digestion better than cold</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Herbal teas: ginger, turmeric, fennel</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span className="text-muted-foreground">Avoid sugary drinks and excess caffeine</span>
                </li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Foods to Avoid */}
        <Card className="p-8 bg-destructive/5 border border-destructive/20 mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Foods to Limit or Avoid</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-foreground mb-3">High Glycemic Foods</h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">White bread and refined grains</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">Sugary drinks and desserts</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">Processed foods and fast food</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-3">Inflammatory Foods</h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">Excess saturated fats</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">Trans fats and fried foods</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">✕</span>
                  <span className="text-muted-foreground">Excess salt and sodium</span>
                </li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Meal Prep Tips */}
        <Card className="p-8 bg-primary/5 border border-primary/20">
          <h2 className="text-2xl font-bold text-foreground mb-4">Meal Preparation Tips</h2>
          <ul className="space-y-3">
            <li className="flex gap-3">
              <span className="text-primary font-bold">1.</span>
              <span className="text-foreground">Plan meals for the week to ensure consistency and variety</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">2.</span>
              <span className="text-foreground">Cook in batches and store in glass containers for easy access</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">3.</span>
              <span className="text-foreground">Use fresh, seasonal ingredients whenever possible</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">4.</span>
              <span className="text-foreground">Eat mindfully and chew thoroughly for better digestion</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">5.</span>
              <span className="text-foreground">Maintain consistent meal times to support digestive rhythm</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
