"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { NadiForm } from "@/components/nadi-form"
import { VCFUpload } from "@/components/vcf-upload"
import { PulseDetector } from "@/components/pulse-detector"

interface AssessmentData {
  vcfFile?: File
  nadiData?: Record<string, string>
  pulseData?: { heartRate: number; dosha: string }
}

export default function AssessmentPage() {
  const [activeTab, setActiveTab] = useState<"vcf" | "nadi" | "pulse">("vcf")
  const [assessmentData, setAssessmentData] = useState<AssessmentData>({})
  const [isLoading, setIsLoading] = useState(false)
  const [results, setResults] = useState<any>(null)

  const handleVCFUpload = (file: File) => {
    setAssessmentData((prev) => ({ ...prev, vcfFile: file }))
  }

  const handleNadiSubmit = (data: Record<string, string>) => {
    setAssessmentData((prev) => ({ ...prev, nadiData: data }))
    setActiveTab("pulse")
  }

  const handlePulseDetected = (data: { heartRate: number; dosha: string }) => {
    setAssessmentData((prev) => ({ ...prev, pulseData: data }))
  }

  const handleFinalSubmit = async () => {
    setIsLoading(true)
    // Simulate API call to process all data
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock results
    setResults({
      dosha: assessmentData.pulseData?.dosha || "Vata",
      diseases: [
        { name: "Type 2 Diabetes", risk: 65, severity: "High" },
        { name: "Hypertensive Heart Disease", risk: 52, severity: "Medium" },
        { name: "Arrhythmia", risk: 38, severity: "Medium" },
        { name: "Ischemic Stroke", risk: 45, severity: "Medium" },
        { name: "Rheumatic Heart Disease", risk: 28, severity: "Low" },
      ],
    })
    setIsLoading(false)
  }

  if (results) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 p-6">
        <div className="max-w-4xl mx-auto">
          <Button
            onClick={() => {
              setResults(null)
              setAssessmentData({})
              setActiveTab("vcf")
            }}
            variant="ghost"
            className="mb-6 text-primary hover:bg-primary/10"
          >
            ← Back to Assessment
          </Button>

          <Card className="p-8 bg-card border-border">
            <h1 className="text-3xl font-bold text-foreground mb-2">Your Health Assessment Results</h1>
            <p className="text-muted-foreground mb-8">Based on your genomic data and Nadi analysis</p>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="p-6 bg-primary/5 border border-primary/20 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Your Dosha</p>
                <p className="text-3xl font-bold text-primary">{results.dosha}</p>
              </div>
              <div className="p-6 bg-accent/5 border border-accent/20 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Assessment Status</p>
                <p className="text-lg font-semibold text-accent">Complete</p>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold text-foreground mb-4">Disease Risk Profile</h2>
              <div className="space-y-3">
                {results.diseases.map((disease: any) => (
                  <div key={disease.name} className="p-4 bg-card border border-border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-foreground">{disease.name}</h3>
                      <span
                        className={`text-xs font-semibold px-2 py-1 rounded ${
                          disease.severity === "High"
                            ? "bg-destructive/10 text-destructive"
                            : disease.severity === "Medium"
                              ? "bg-accent/10 text-accent"
                              : "bg-primary/10 text-primary"
                        }`}
                      >
                        {disease.severity}
                      </span>
                    </div>
                    <div className="w-full bg-border rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          disease.severity === "High"
                            ? "bg-destructive"
                            : disease.severity === "Medium"
                              ? "bg-accent"
                              : "bg-primary"
                        }`}
                        style={{ width: `${disease.risk}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">{disease.risk}% Risk Score</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 p-6 bg-secondary/10 border border-secondary/20 rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">Next Steps</p>
              <p className="text-foreground">
                Based on your results, we recommend personalized exercise and diet recommendations. Continue to the next
                section to receive tailored guidance.
              </p>
            </div>

            <Button className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground">
              View Recommendations
            </Button>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Health Assessment</h1>
          <p className="text-muted-foreground">
            Complete your genomic and Nadi analysis for personalized recommendations
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-8 border-b border-border">
          <button
            onClick={() => setActiveTab("vcf")}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === "vcf"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            1. Genomic Data
          </button>
          <button
            onClick={() => setActiveTab("nadi")}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === "nadi"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            2. Nadi Assessment
          </button>
          <button
            onClick={() => setActiveTab("pulse")}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === "pulse"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            3. Pulse Detection
          </button>
        </div>

        {/* Tab Content */}
        <Card className="p-8 bg-card border-border mb-8">
          {activeTab === "vcf" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Upload Genomic Data</h2>
                <p className="text-muted-foreground">
                  Upload your VCF (Variant Call Format) file for genomic risk analysis using GWAS data.
                </p>
              </div>
              <VCFUpload onFileSelect={handleVCFUpload} isLoading={isLoading} />
              {assessmentData.vcfFile && (
                <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm text-primary font-medium">✓ File uploaded: {assessmentData.vcfFile.name}</p>
                </div>
              )}
              <Button
                onClick={() => setActiveTab("nadi")}
                disabled={!assessmentData.vcfFile}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Continue to Nadi Assessment
              </Button>
            </div>
          )}

          {activeTab === "nadi" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Nadi Assessment Form</h2>
                <p className="text-muted-foreground">
                  Answer questions about your physical and behavioral characteristics to determine your Dosha.
                </p>
              </div>
              <NadiForm onSubmit={handleNadiSubmit} isLoading={isLoading} />
            </div>
          )}

          {activeTab === "pulse" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Pulse Detection</h2>
                <p className="text-muted-foreground">
                  Use your camera to detect your pulse pattern for additional Dosha confirmation.
                </p>
              </div>
              <PulseDetector onPulseDetected={handlePulseDetected} isLoading={isLoading} />
              {assessmentData.pulseData && (
                <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">Detected Dosha</p>
                  <p className="text-lg font-semibold text-primary">{assessmentData.pulseData.dosha}</p>
                </div>
              )}
              <Button
                onClick={handleFinalSubmit}
                disabled={!assessmentData.pulseData || isLoading}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {isLoading ? "Processing..." : "Get Results"}
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
